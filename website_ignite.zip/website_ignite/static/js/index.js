// Função para o botão "Inicio"
document.getElementById("home-button").addEventListener("click", function () {
    // Redireciona para o arquivo index.html
    window.location.href = "/";
});

// Função para o botão "Sistema"
document.getElementById("system-button").addEventListener("click", function () {
    // Redireciona para o arquivo pSystem.html
    window.location.href = "/system";
});

// Função para o botão "Equipamento"
document.getElementById("equipment-button").addEventListener("click", function () {
    // Redireciona para o arquivo pEquipment.html
    window.location.href = "/equipment";
});

// Função para o botão "Personagem"
document.getElementById("character-button").addEventListener("click", function () {
    // Redireciona para o arquivo pCharacter.html
    window.location.href = "/character";
});

// Função para o botão "Dados"
document.getElementById("dice-button").addEventListener("click", function () {
    // Redireciona para o arquivo pDice.html
    window.location.href = "/dice";
});

// Função para o botão "Mapa"
document.getElementById("map-button").addEventListener("click", function () {
    // Redireciona para o arquivo pDice.html
    window.location.href = "/map";
  });