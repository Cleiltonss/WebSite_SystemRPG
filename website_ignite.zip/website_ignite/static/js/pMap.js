// Função para o botão "Inicio"
document.getElementById("home-button").addEventListener("click", function () {
  // Redireciona para o arquivo index.html
  window.location.href = "/";
});

// Função para o botão "Sistema"
document.getElementById("system-button").addEventListener("click", function () {
  // Redireciona para o arquivo pSystem.html
  window.location.href = "/system";
});

// Função para o botão "Equipamento"
document.getElementById("equipment-button").addEventListener("click", function () {
  // Redireciona para o arquivo pEquipment.html
  window.location.href = "/equipment";
});

// Função para o botão "Personagem"
document.getElementById("character-button").addEventListener("click", function () {
  // Redireciona para o arquivo pCharacter.html
  window.location.href = "/character";
});

// Função para o botão "Dados"
document.getElementById("dice-button").addEventListener("click", function () {
  // Redireciona para o arquivo pDice.html
  window.location.href = "/dice";
});

// Função para o botão "Mapa"
document.getElementById("map-button").addEventListener("click", function () {
  // Redireciona para o arquivo pDice.html
  window.location.href = "/map";
});




const uploadBtn = document.getElementById("upload-btn");
const fileInput = document.getElementById("file-input");
const canvas = document.getElementById("map-canvas");
const ctx = canvas.getContext("2d");

const gridSize = 50;

uploadBtn.addEventListener("click", () => {
  fileInput.click();
});

fileInput.addEventListener("change", (event) => {
  const file = event.target.files[0];
  if (!file) return;

  const reader = new FileReader();
  reader.onload = (e) => {
    const img = new Image();
    img.onload = () => {
      canvas.width = img.width;
      canvas.height = img.height;
      ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
      drawGrid();
    };
    img.src = e.target.result;
  };
  reader.readAsDataURL(file);
});

function drawGrid() {
  ctx.strokeStyle = "#ffffff";
  ctx.lineWidth = 0.7;

  for (let x = 0; x < canvas.width; x += gridSize) {
    ctx.beginPath();
    ctx.moveTo(x, 0);
    ctx.lineTo(x, canvas.height);
    ctx.stroke();
  }

  for (let y = 0; y < canvas.height; y += gridSize) {
    ctx.beginPath();
    ctx.moveTo(0, y);
    ctx.lineTo(canvas.width, y);
    ctx.stroke();
  }
}
