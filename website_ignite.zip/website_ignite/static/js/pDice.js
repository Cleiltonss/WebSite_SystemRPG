// Navigation buttons
document.getElementById("home-button").addEventListener("click", () => window.location.href = "/");
document.getElementById("system-button").addEventListener("click", () => window.location.href = "/system");
document.getElementById("equipment-button").addEventListener("click", () => window.location.href = "/equipment");
document.getElementById("character-button").addEventListener("click", () => window.location.href = "/character");
document.getElementById("dice-button").addEventListener("click", () => window.location.href = "/dice");

// Função para o botão "Mapa"
document.getElementById("map-button").addEventListener("click", function () {
  // Redireciona para o arquivo pDice.html
  window.location.href = "/map";
});

let scene, camera, renderer, cube;
let isRolling = false;
let rollingTime = 0;
let stopRotation = false;
let targetRotation = [0, 0];

function initThreeScene() {
  const container = document.getElementById("three-container");
  const width = 400;
  const height = 400;

  scene = new THREE.Scene();
  camera = new THREE.PerspectiveCamera(75, width / height, 0.1, 1000);
  camera.position.z = 3;

  renderer = new THREE.WebGLRenderer({ alpha: true });
  renderer.setSize(width, height);
  container.appendChild(renderer.domElement);

  const loader = new THREE.TextureLoader();
  const materials = [
    new THREE.MeshBasicMaterial({ map: loader.load('/static/images_dice/d6_f1.png') }),
    new THREE.MeshBasicMaterial({ map: loader.load('/static/images_dice/d6_f6.png') }),
    new THREE.MeshBasicMaterial({ map: loader.load('/static/images_dice/d6_f3.png') }),
    new THREE.MeshBasicMaterial({ map: loader.load('/static/images_dice/d6_f4.png') }),
    new THREE.MeshBasicMaterial({ map: loader.load('/static/images_dice/d6_f5.png') }),
    new THREE.MeshBasicMaterial({ map: loader.load('/static/images_dice/d6_f2.png') })
  ];

  cube = new THREE.Mesh(new THREE.BoxGeometry(), materials);
  scene.add(cube);
}

function animate() {
  requestAnimationFrame(animate);

  if (isRolling) {
    cube.rotation.x += 0.3;
    cube.rotation.y += 0.3;
    rollingTime += 1;
  }

  if (stopRotation && rollingTime > 60) {
    isRolling = false;
    stopRotation = false;
    cube.rotation.x = targetRotation[0];
    cube.rotation.y = targetRotation[1];
    document.getElementById("katie").classList.remove("rolling");
  }

  renderer.render(scene, camera);
}

function rollDice() {
  if (isRolling) return;

  isRolling = true;
  rollingTime = 0;
  stopRotation = true;

  const katie = document.getElementById("katie");
  katie.classList.add("rolling");

  // Call C++ function
  const result = Module.ccall("rollDice", "number", [], []);
  console.log("Rolled value:", result);

  const rotations = [
    [0, 0],               // 1
    [Math.PI, 0],         // 2
    [Math.PI / 2, 0],     // 3
    [-Math.PI / 2, 0],    // 4
    [0, -Math.PI / 2],    // 5
    [0, Math.PI / 2]      // 6
  ];

  targetRotation = rotations[result - 1];
}

window.addEventListener("DOMContentLoaded", () => {
  initThreeScene();
  animate();

  if (typeof Module !== "undefined" && Module.onRuntimeInitialized) {
    Module.onRuntimeInitialized = () => {
      document.getElementById("rollDice-button").addEventListener("click", rollDice);
    };
  } else {
    document.getElementById("rollDice-button").addEventListener("click", rollDice);
  }
});
